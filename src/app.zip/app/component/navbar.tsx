import Link from 'next/link'

export default function Navbar(){
    return (
         
        <nav className='flex items-center justify-center fixed top-0 left-0 right-0'>
            <div className="flex items-center justify-between p-3 bg-surface rounded-3xl max-w-3xl absolute top-10">
                <Link href="/home" className="bg-surface text-amber-50 p-3 ml-5 mr-5 rounded-2xl">Home</Link>
                <div className="bg-surface text-amber-50 p-3 ml-5 mr-5 rounded-2xl">Contact Me</div>
            </div>
        </nav>
    )
}