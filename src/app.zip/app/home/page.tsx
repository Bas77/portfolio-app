import Image from "next/image";

export default function Home() {
  return (
    <div className="grid grid-rows-[20px_1fr_20px] items-center justify-items-center min-h-screen p-8 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)] pb-200 bg-zinc-800">
        <div className="mt-150 p-75 font-bold text-blue-50 bg-black">
            <div className="">
                <h1>Dominikus Sebastian Ramli</h1>
                <h4>Software Developer</h4>
            </div>
        </div>
    </div>
  );
}
